<?php require("template/header.php") ?>
<?php
 session_destroy();
 echo '<meta http-equiv="refresh" content="0;url=login.php">';
 ?>
<?php require("template/footer.php") ?>
